# ros_sensor_topic

A utility package to find ROS topic names for color, depth and camera info streams for Luxonis and RealSense devices.